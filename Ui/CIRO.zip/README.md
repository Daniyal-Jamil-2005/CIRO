
  # CIRO

  This is a code bundle for CIRO. The original project is available at https://www.figma.com/design/jRitmSCInTwPMYIQQrj8gx/CIRO.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  